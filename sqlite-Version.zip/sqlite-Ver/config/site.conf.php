<?php
# database configs  Test Server
define('SyDB_USERNAME',"user");
define('SyDB_PASSWORD',"userpass");
define('SyDB_DATABASE',"test_data");
define('SyDB_HOSTNAME',"tstserver.ad.domain");

# database configs  Production Server
define('SyDB_USERNAME_PROD',"user");
define('SyDB_PASSWORD_PROD',"userpass");
define('SyDB_DATABASE_PROD',"prd_data");
define('SyDB_HOSTNAME_PROD',"server.ad.domain");


date_default_timezone_set('America/New_York');
?>
